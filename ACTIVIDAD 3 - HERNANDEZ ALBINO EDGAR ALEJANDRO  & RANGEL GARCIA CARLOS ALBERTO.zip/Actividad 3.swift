// Hernández Albino Edgar Alejandro
// Rangel García Carlos Alberto

protocol Taco {
  func precio() -> Double
  func ingrediente() -> String
}

class TacoSimple: Taco {

    func precio () -> Double{return 0}

    func ingrediente() -> String{return "TacoSimple"}
}

class Carnitas: Taco {

    func precio () -> Double{
      return 15
    }

    func ingrediente() -> String{
      return "Carnitas"
    }
}

class Suadero: Taco {

    func precio () -> Double{
      return 12
    }

    func ingrediente() -> String{
      return "Sudero"
    }
}

class Cecina: Taco {

    func precio () -> Double{
      return 15
    }

    func ingrediente() -> String{
      return "Cecina"
    }
}

class Pastor: Taco {

    func precio () -> Double{
      return 12
    }

    func ingrediente() -> String{
      return "Pastor"
    }
}

class IngredienteDecorator: Taco{

    private var taco: Taco

     init(taco: Taco){
       self.taco = taco
     }

     func precio() -> Double{
       return taco.precio()
     }

     func ingrediente() -> String{
       return taco.ingrediente()
     }
   }

class Cilantro: IngredienteDecorator{

      override func precio()-> Double{
          return super.precio() + 2
      }

      override func ingrediente() -> String{
        return super.ingrediente() + ",Cilantro"
      }

}

class Cebolla: IngredienteDecorator{
       override func precio() -> Double{
          return super.precio() + 2
      }

      override func ingrediente() -> String{
        return super.ingrediente() + ",Cebolla"
      }
     }

class Salsa: IngredienteDecorator{
       override func precio() -> Double{
          return super.precio() + 10
      }

      override func ingrediente() -> String{
        return super.ingrediente() + ",Salsa"
      }
     }

class Limon: IngredienteDecorator{
       override func precio() -> Double{
          return super.precio() + 3
      }

      override func ingrediente() -> String{
        return super.ingrediente() + ",Limon"
      }
     }


//VARIABLES///////////////////////////////
var num_limones: Int
var num_cebolla: Int
var num_tacos: Int
var num_cilantro: Int
var num_salsa: Int
var nombre_taco: String
var afirmacion: String
var precio = 0.0
var refresco: Int
var index = 1
var ingredientes: [Int] = [0,0,0,0,0]
var taco: Taco = TacoSimple()
/////////////////////////////////////////

print("----------------- Cuenta \(index)----------------")

while true {

  print("¿Cuántos tacos van a ser joven?")
  num_tacos = (Int(readLine()!))!

  for num_t in 1...num_tacos{

    print("""
    \n¿De qué es el taco: \(num_t)? 
    -Carnitas
    -Sudero
    -Pastor
    -Cecina\n
    """)
    nombre_taco = readLine()!

    if (nombre_taco.lowercased() == "carnitas" ){
      taco = Carnitas()
      //print("Soy un taco de Carmitas")
    }
    else if(nombre_taco.lowercased() == "suadero" ){
      taco = Suadero()
      //print("Soy un taco de Suadero")
    }
    else if(nombre_taco.lowercased() == "pastor" ){
      taco = Pastor()
      //print("Soy un taco de Pastor")
    }
    else if(nombre_taco.lowercased() == "cecina" ){
      taco = Cecina()
      //print("Soy un taco de Cecina")
    }

    print("\n¿Lleva Cebolla? (Si/No)")
    afirmacion = readLine()!

    if(afirmacion.lowercased() == "si" ){
      print("\n¿Cuántas ordenes de Cebolla?")
      num_cebolla = (Int(readLine()!))!
      for _ in 1...num_cebolla {
        taco = Cebolla(taco: taco)
        ingredientes[0] += 2
      }
    }

    print("\n¿Lleva Limones? (Si/No)")
    afirmacion = readLine()!

    if(afirmacion.lowercased() == "si" ){
      print("\n¿Cuántos Limones?")
      num_limones = (Int(readLine()!))!
      for _ in 1...num_limones {
      taco = Limon(taco: taco)
      ingredientes[1] += 3
      }
    }

    print("\n¿Lleva Sala? (Si/No)")
    afirmacion = readLine()!

    if(afirmacion.lowercased() == "si" ){
      print("\n¿Cuántas órdenes de Salsa?")
      num_salsa = (Int(readLine()!))!
      for _ in 1...num_salsa {
      taco = Salsa(taco: taco)
      ingredientes[2] += 10
      }
    }

    print("\n¿Lleva Cilantro? (Si/No)")
    afirmacion = readLine()!

    if(afirmacion.lowercased() == "si" ){
      print("\n¿Cuántas órdenes de Cilantro?")
      num_cilantro = (Int(readLine()!))!
      for _ in 1...num_cilantro {
      taco = Cilantro(taco: taco)
      ingredientes[3] += 2
      }
    }

    print("\nEl Precio del taco: \(num_t) es: $\(taco.precio())")
    print("Los Ingredientes de tu taco son:\(taco.ingrediente())")
    precio = taco.precio() +  precio

  }

  print("\n¿Gusta agregar una bebida? (Si/No)")
  afirmacion = readLine()!

  if(afirmacion.lowercased() == "si" ){
      print("""
      \n
      (1)Agua Simple      = $10
      (2)Fanta            = $15
      (3)CocaCola         = $16
      (4)Agua de Horchata = $12
      Ingresa el código de la bebida (1-4)
      """)
      refresco = (Int(readLine()!))!
      switch refresco {
        case 1:
            ingredientes[4] += 10
            precio += 10
        case 2:
            ingredientes[4] += 15
            precio += 15
        case 3:
            ingredientes[4] += 16
            precio += 16
        case 4:
            ingredientes[4] += 12
            precio += 12
        default:
            print("Opcion no Valida sin bebida")
    }
  }

  print("\nEl Total de la Cuenta \(index) es: $\(precio)")
  print("\nGasto Total en Cebolla: $\(ingredientes[0])")
  print("\nGasto Total en Limones: $\(ingredientes[1])")
  print("\nGasto Total en Salsa: $\(ingredientes[2])")
  print("\nGasto Total en Cilantro: $\(ingredientes[3])")
  print("\nGasto Total en Bebida: $\(ingredientes[4])")

  print("""
  \n¿Quiere formular otra cuenta?
              Si=Continuar
              No=Salir
  """)
  afirmacion = readLine()!

  if (afirmacion.lowercased() == "no"){
    print("¡Vuelva pronto!\n")
    break;
  }
  else if (afirmacion.lowercased() == "si"){
    print("¡OK!\n")
    index += 1
    ingredientes = [0,0,0,0,0]
    precio = 0
    print("----------------- Cuenta \(index)----------------")
  }
  else{
    print("Opcion no valida adios.\n")
    break;
  }
}

